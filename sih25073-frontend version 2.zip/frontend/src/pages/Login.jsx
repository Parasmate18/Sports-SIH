import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Loading from '../components/Loading';
import ErrorMessage from '../components/ErrorMessage';
import { loginUser } from '../services/api';

export default function Login() {
  const navigate = useNavigate();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [status, setStatus] = useState('idle'); // idle | loading | error
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus('loading');
    setError('');
    try {
      const data = await loginUser(username, password);
      localStorage.setItem('sih_token', data.token);
      localStorage.setItem('sih_username', data.username);
      navigate('/upload');
    } catch (err) {
      setError(err.message || 'Login failed. Please try again.');
      setStatus('error');
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-[#0B0F14] px-4">
      <div className="relative w-full max-w-sm rounded-xl border border-[#232D36] bg-[#131A21] px-6 py-8">
        <span className="pointer-events-none absolute left-2 top-2 h-4 w-4 border-l-2 border-t-2 border-[#00E5A8]" />
        <span className="pointer-events-none absolute right-2 top-2 h-4 w-4 border-r-2 border-t-2 border-[#00E5A8]" />
        <span className="pointer-events-none absolute bottom-2 left-2 h-4 w-4 border-b-2 border-l-2 border-[#00E5A8]" />
        <span className="pointer-events-none absolute bottom-2 right-2 h-4 w-4 border-b-2 border-r-2 border-[#00E5A8]" />

        <div className="mb-6 text-center">
          <div className="mx-auto mb-2 h-2 w-2 rounded-full bg-[#00E5A8] shadow-[0_0_8px_#00E5A8]" />
          <h1 className="font-display text-xl font-semibold text-[#F5F7FA]">SIH25073</h1>
          <p className="text-xs text-[#8B98A5]">Sign in to Sports Talent Assessment</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="font-mono text-[11px] uppercase tracking-wider text-[#8B98A5]">
              Username
            </label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              autoComplete="username"
              className="mt-2 w-full rounded-md border border-[#232D36] bg-[#0B0F14] px-3 py-2 text-sm text-[#F5F7FA] focus:border-[#00E5A8] focus:outline-none"
              placeholder="your.username"
            />
          </div>
          <div>
            <label className="font-mono text-[11px] uppercase tracking-wider text-[#8B98A5]">
              Password
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="current-password"
              className="mt-2 w-full rounded-md border border-[#232D36] bg-[#0B0F14] px-3 py-2 text-sm text-[#F5F7FA] focus:border-[#00E5A8] focus:outline-none"
              placeholder="••••••••"
            />
          </div>

          {status === 'error' && (
            <ErrorMessage message={error} onRetry={() => setStatus('idle')} />
          )}

          {status === 'loading' ? (
            <Loading message="Signing in…" />
          ) : (
            <button
              type="submit"
              disabled={!username || !password}
              className="w-full rounded-md bg-[#FF4B2B] py-3 font-display text-sm font-semibold text-[#0B0F14] transition-opacity disabled:cursor-not-allowed disabled:opacity-40"
            >
              Sign in
            </button>
          )}
        </form>

        <p className="mt-4 text-center font-mono text-[10px] text-[#8B98A5]">
          Mock auth — any username + password (4+ chars) works for now.
        </p>
      </div>
    </div>
  );
}
