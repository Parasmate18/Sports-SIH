import { useState } from 'react';
import Navbar from '../components/Navbar';
import UploadBox from '../components/UploadBox';
import Loading from '../components/Loading';
import ErrorMessage from '../components/ErrorMessage';
import { analyzeVideo } from '../services/api';

const EXERCISES = [
  { id: 'vertical_jump', label: 'Vertical Jump' },
  { id: 'shuttle_run', label: 'Shuttle Run' },
  { id: 'sit_ups', label: 'Sit-Ups' },
  { id: 'sit_and_reach', label: 'Sit and Reach' },
];

export default function Upload() {
  const [exercise, setExercise] = useState(EXERCISES[0].id);
  const [file, setFile] = useState(null);
  const [status, setStatus] = useState('idle'); // idle | loading | error | success
  const [error, setError] = useState('');
  const [result, setResult] = useState(null);

  const handleAnalyze = async () => {
    if (!file) {
      setError('Select a video before analyzing.');
      setStatus('error');
      return;
    }
    setStatus('loading');
    setError('');
    try {
      const data = await analyzeVideo(file, exercise);
      setResult(data);
      setStatus('success');
      console.log('Analysis result:', data); // Results page (Step 3) will consume this
    } catch (err) {
      setError(err.message || 'Analysis failed. Please try again.');
      setStatus('error');
    }
  };

  return (
    <div className="min-h-screen bg-[#0B0F14] pb-16">
      <Navbar />
      <main className="mx-auto max-w-md px-4 pt-8 sm:max-w-2xl">
        <h1 className="font-display text-2xl font-semibold text-[#F5F7FA]">Submit your attempt</h1>
        <p className="mt-1 text-sm text-[#8B98A5]">
          Pick an exercise, upload a clear video, and let the AI score your form.
        </p>

        <div className="mt-6">
          <label className="font-mono text-[11px] uppercase tracking-wider text-[#8B98A5]">
            Exercise
          </label>
          <select
            value={exercise}
            onChange={(e) => setExercise(e.target.value)}
            className="mt-2 w-full rounded-md border border-[#232D36] bg-[#131A21] px-3 py-2 text-sm text-[#F5F7FA] focus:border-[#00E5A8] focus:outline-none"
          >
            {EXERCISES.map((ex) => (
              <option key={ex.id} value={ex.id}>
                {ex.label}
              </option>
            ))}
          </select>
        </div>

        <div className="mt-6">
          <UploadBox file={file} onFileSelected={setFile} />
        </div>

        {status === 'error' && (
          <div className="mt-4">
            <ErrorMessage message={error} onRetry={() => setStatus('idle')} />
          </div>
        )}

        {status === 'loading' ? (
          <Loading message="Uploading & analyzing…" />
        ) : (
          <button
            onClick={handleAnalyze}
            disabled={!file}
            className="mt-6 w-full rounded-md bg-[#FF4B2B] py-3 font-display text-sm font-semibold text-[#0B0F14] transition-opacity disabled:cursor-not-allowed disabled:opacity-40"
          >
            Analyze video
          </button>
        )}

        {status === 'success' && result && (
          <p className="mt-4 text-center text-xs text-[#00E5A8]">
            Analysis complete — Results page will render this in the next step.
          </p>
        )}
      </main>
    </div>
  );
}
