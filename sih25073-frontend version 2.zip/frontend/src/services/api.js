const USE_MOCK = true;
const BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';

function mockAnalyze(file, exercise) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (Math.random() < 0.05) {
        reject(new Error('Mock failure: pose could not be detected. Try better lighting.'));
        return;
      }
      resolve({
        exercise,
        fileName: file.name,
        score: 78,
        grade: 'B+',
        metrics: [
          { label: 'Jump Height', value: '42 cm' },
          { label: 'Takeoff Angle', value: '86°' },
          { label: 'Symmetry', value: '91%' },
        ],
        feedback: [
          'Good extension at takeoff.',
          'Landing knee flexion is slightly shallow — bend more on impact.',
        ],
      });
    }, 1800);
  });
}

function mockLogin(username, password) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (!username || !password) {
        reject(new Error('Enter both username and password.'));
        return;
      }
      if (password.length < 4) {
        reject(new Error('Invalid credentials. Try again.'));
        return;
      }
      resolve({ token: `mock-token-${Date.now()}`, username });
    }, 900);
  });
}

export async function loginUser(username, password) {
  if (USE_MOCK) return mockLogin(username, password);

  const res = await fetch(`${BASE_URL}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password }),
  });

  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.message || 'Login failed.');
  }
  return res.json();
}

export async function analyzeVideo(file, exercise) {
  if (USE_MOCK) return mockAnalyze(file, exercise);

  const formData = new FormData();
  formData.append('video', file);
  formData.append('exercise', exercise);

  const res = await fetch(`${BASE_URL}/api/analyze`, {
    method: 'POST',
    body: formData,
  });

  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.message || 'Analysis failed.');
  }
  return res.json();
}
