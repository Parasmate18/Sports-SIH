export default function Loading({ message = 'Analyzing movement…' }) {
  return (
    <div className="flex flex-col items-center justify-center gap-4 py-12">
      <div className="relative h-14 w-14">
        <span className="absolute inset-0 animate-ping rounded-full bg-[#00E5A8]/30" />
        <span className="absolute inset-3 rounded-full bg-[#00E5A8]" />
      </div>
      <p className="font-mono text-xs uppercase tracking-widest text-[#8B98A5]">
        {message}
      </p>
    </div>
  );
}
