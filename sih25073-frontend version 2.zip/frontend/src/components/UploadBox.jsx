import { useRef, useState } from 'react';

const ACCEPTED_TYPES = ['video/mp4', 'video/quicktime', 'video/webm'];
const MAX_SIZE_MB = 200;

export default function UploadBox({ file, onFileSelected }) {
  const inputRef = useRef(null);
  const [isDragging, setIsDragging] = useState(false);
  const [localError, setLocalError] = useState('');

  const validate = (candidate) => {
    if (!ACCEPTED_TYPES.includes(candidate.type)) {
      return 'Unsupported format. Use MP4, MOV, or WebM.';
    }
    if (candidate.size > MAX_SIZE_MB * 1024 * 1024) {
      return `File too large. Keep it under ${MAX_SIZE_MB}MB.`;
    }
    return '';
  };

  const handleFiles = (fileList) => {
    const candidate = fileList?.[0];
    if (!candidate) return;
    const err = validate(candidate);
    if (err) {
      setLocalError(err);
      return;
    }
    setLocalError('');
    onFileSelected(candidate);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    handleFiles(e.dataTransfer.files);
  };

  return (
    <div>
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        className={`relative flex flex-col items-center justify-center gap-3 rounded-xl border border-dashed px-6 py-12 text-center transition-colors ${
          isDragging ? 'border-[#00E5A8] bg-[#00E5A8]/5' : 'border-[#232D36] bg-[#131A21]'
        }`}
      >
        {/* corner brackets — scan-target motif */}
        <span className="pointer-events-none absolute left-2 top-2 h-4 w-4 border-l-2 border-t-2 border-[#00E5A8]" />
        <span className="pointer-events-none absolute right-2 top-2 h-4 w-4 border-r-2 border-t-2 border-[#00E5A8]" />
        <span className="pointer-events-none absolute bottom-2 left-2 h-4 w-4 border-b-2 border-l-2 border-[#00E5A8]" />
        <span className="pointer-events-none absolute bottom-2 right-2 h-4 w-4 border-b-2 border-r-2 border-[#00E5A8]" />

        <p className="font-display text-sm font-medium text-[#F5F7FA]">
          Drag & drop your attempt video
        </p>
        <p className="text-xs text-[#8B98A5]">MP4, MOV or WebM · up to {MAX_SIZE_MB}MB</p>

        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          className="mt-2 rounded-md border border-[#00E5A8]/50 px-4 py-2 font-mono text-xs uppercase tracking-wider text-[#00E5A8] hover:bg-[#00E5A8]/10"
        >
          Browse files
        </button>
        <input
          ref={inputRef}
          type="file"
          accept="video/mp4,video/quicktime,video/webm"
          className="hidden"
          onChange={(e) => handleFiles(e.target.files)}
        />
      </div>

      {localError && <p className="mt-2 text-xs text-[#FF4B2B]">{localError}</p>}

      {file && (
        <div className="mt-4 flex items-center justify-between rounded-lg border border-[#232D36] bg-[#131A21] px-4 py-3">
          <div>
            <p className="text-sm text-[#F5F7FA]">{file.name}</p>
            <p className="font-mono text-[11px] text-[#8B98A5]">
              {(file.size / (1024 * 1024)).toFixed(1)} MB
            </p>
          </div>
          <span className="h-2 w-2 rounded-full bg-[#00E5A8]" />
        </div>
      )}
    </div>
  );
}
