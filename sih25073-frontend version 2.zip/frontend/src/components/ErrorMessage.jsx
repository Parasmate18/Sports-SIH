export default function ErrorMessage({ message, onRetry }) {
  if (!message) return null;
  return (
    <div className="flex items-start gap-3 rounded-lg border border-[#FF4B2B]/40 bg-[#FF4B2B]/10 px-4 py-3">
      <span className="mt-0.5 h-2 w-2 flex-shrink-0 rounded-full bg-[#FF4B2B]" />
      <div className="flex-1">
        <p className="text-sm text-[#F5F7FA]">{message}</p>
        {onRetry && (
          <button
            onClick={onRetry}
            className="mt-2 font-mono text-xs uppercase tracking-wider text-[#FF4B2B] underline underline-offset-2"
          >
            Try again
          </button>
        )}
      </div>
    </div>
  );
}
