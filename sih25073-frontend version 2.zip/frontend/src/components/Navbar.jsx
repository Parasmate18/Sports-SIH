import { useNavigate } from 'react-router-dom';

export default function Navbar() {
  const navigate = useNavigate();
  const username = localStorage.getItem('sih_username');

  const handleLogout = () => {
    localStorage.removeItem('sih_token');
    localStorage.removeItem('sih_username');
    navigate('/');
  };

  return (
    <header className="sticky top-0 z-10 border-b border-[#232D36] bg-[#0B0F14]/90 backdrop-blur">
      <div className="mx-auto flex max-w-md items-center justify-between px-4 py-3 sm:max-w-2xl">
        <div className="flex items-center gap-2">
          <span className="h-2 w-2 rounded-full bg-[#00E5A8] shadow-[0_0_8px_#00E5A8]" />
          <div>
            <p className="font-display text-sm font-semibold tracking-wide text-[#F5F7FA]">
              SIH25073
            </p>
            <p className="text-[11px] text-[#8B98A5]">Sports Talent Assessment</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <nav className="font-mono text-[11px] uppercase tracking-wider text-[#8B98A5]">
            <span className="text-[#00E5A8]">Upload</span>
            <span className="mx-2 text-[#232D36]">/</span>
            <span>Results</span>
            <span className="mx-2 text-[#232D36]">/</span>
            <span>Dashboard</span>
          </nav>
          {username && (
            <button
              onClick={handleLogout}
              className="font-mono text-[11px] uppercase tracking-wider text-[#FF4B2B] hover:underline"
            >
              Logout
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
