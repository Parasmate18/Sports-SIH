# SIH25073 — Frontend (M3)

AI-Powered Mobile Platform for Democratizing Sports Talent Assessment — Frontend module.

## Setup

```bash
npm install
npm run dev
```

Runs at http://localhost:5173.

## Status

- [x] Step 1: Project scaffold
- [x] Step 2: Upload page (exercise select, drag & drop, browse, loading, error states)
- [x] Step 3: Login page (first page of the app, guards the Upload route)
- [ ] Step 4: Results page
- [ ] Step 5: Dashboard + charts
- [ ] Step 6: AI feedback cards
- [ ] Step 7: Swap mock data in `src/services/api.js` for the real backend

## Auth (current state — mock only)

`src/pages/Login.jsx` posts to `loginUser()` in `src/services/api.js`, which is mocked
(`USE_MOCK = true`): any non-empty username with a password of 4+ characters succeeds.
A fake token is stored in `localStorage` (`sih_token`, `sih_username`). `/upload` is
wrapped in `ProtectedRoute`, which redirects to `/` if no token is present. Logout is in
the Navbar. None of this is real security — it exists so navigation/UI flows correctly
until the backend team wires up real auth, at which point only `loginUser()` needs to
change (same pattern as `analyzeVideo()`).

## Notes

- `src/services/api.js` currently returns mock data (`USE_MOCK = true`). To connect
  the real backend, set `USE_MOCK = false` and point `VITE_API_BASE_URL` at it
  (via a `.env` file — see `.gitignore`, it's already excluded from commits).
